</div> <!-- /.container -->

<footer class="blog-footer">
    <p>
        WordPress template built for <a href="http://getbootstrap.com">Bootstrap</a> by <a href="">Jeff</a>.
    </p>
    <p>
        <a href="#">Back to top</a>
    </p>
</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<?php wp_footer(); ?>
</body>
</html>